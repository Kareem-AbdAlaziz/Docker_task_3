const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  price: { type: Number, required: true },
  category: String,
  description: String
});

productSchema.index({ name: 1 });

module.exports = mongoose.model('Product', productSchema);
