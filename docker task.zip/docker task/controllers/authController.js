const bcrypt = require('bcrypt');
const User = require('../models/user');

exports.showRegister = (req, res) => res.render('auth/register');
exports.showLogin = (req, res) => res.render('auth/login');

exports.registerUser = async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  await User.create({ username, password: hashed });
  res.redirect('/login');
};

exports.loginUser = async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (user && await bcrypt.compare(password, user.password)) {
    req.session.user = user;
    res.redirect('/products');
  } else {
    res.send('Invalid credentials');
  }
};

exports.logoutUser = (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
};
