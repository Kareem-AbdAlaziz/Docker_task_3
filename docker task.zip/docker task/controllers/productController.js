const Product = require('../models/product');

exports.getAllProducts = async (req, res) => {
  const search = req.query.search || '';
  const products = await Product.find({ name: { $regex: search, $options: 'i' } });
  res.render('products/index', { products, search });
};

exports.showCreateForm = (req, res) => {
  res.render('products/create');
};

exports.createProduct = async (req, res) => {
  const { name, price, category, description } = req.body;
  await Product.create({ name, price, category, description });
  res.redirect('/products');
};

exports.showEditForm = async (req, res) => {
  const product = await Product.findById(req.params.id);
  res.render('products/edit', { product });
};

exports.updateProduct = async (req, res) => {
  const { name, price, category, description } = req.body;
  await Product.findByIdAndUpdate(req.params.id, { name, price, category, description });
  res.redirect('/products');
};

exports.deleteProduct = async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.redirect('/products');
};

exports.getProductDetails = async (req, res) => {
  const product = await Product.findById(req.params.id);
  res.render('products/details', { product });
};
